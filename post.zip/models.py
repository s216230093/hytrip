from django.db import models
from django.conf import settings
from django.contrib import admin

# 리뷰
class Review(models.Model):
    author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    photo = models.ImageField(upload_to='review')
    content = models.TextField('CONTENT')

    # 이 모델이 리스트로 나열되면 어떤 값으로 나타나는지 정함.
    def __str__(self):
        return f'Post (PK: {self.pk}, Author: {self.author.username})'

# 테스트용
class Post(models.Model):
    title = models.CharField(max_length=100)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True) # 최초의 저장된 시간이 저장
    updated_at = models.DateTimeField(auto_now=True) # 매번 저장이 될 때마다 시간이 저장
# 모델 정의 후 makemigrations, migrate를 실행해주기.

    # 관리자 페이지에서 title을 테이블에 출력
    def __unicode__(self):
        return self.title


# 클래스 만들고 post\admin.py의 register에 클래스 추가해주기
class PostAdmin(admin.ModelAdmin):
    list_display = ('id', 'title')

# 공지사항 게시판_HyNotice
class HyNotice(admin.ModelAdmin):
    title = models.CharField(max_length=100)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    count_view = models.PositiveIntegerField(default=0)

# title과 upload할 file에 대한 정보를 갖는 model
class FileModel(models.Model):
    title = models.TextField(default='')
    file = models.FileField(null=True)


# 댓글
class Comment(models.Model):
    post = models.ForeignKey(Review, on_delete=models.PROTECT)
    author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    content = models.TextField()

    def __str__(self):
        return f'Comment (PK: {self.pk}, Author: {self.author.username})'