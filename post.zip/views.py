from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse

from post.forms import CommentForm
from .models import Review, Comment

# post 모델을 표현하기 위한 뷰

# 이 함수는 Review모델의 모든 Object들을 reviews라는 변수에 담음.
# 이후 post폴더 밑의 review_list.html에서 사용될 것.
def review_list(request):
    reviews = Review.objects.all()
    comment_form = CommentForm()
    context = {'reviews': reviews, 'comment_form': comment_form, }
    return render(request, 'post/review_list.html', context)

def comment_create(request, review_pk):
    if request.method == "POST":
        post = get_object_or_404(Review, pk=review_pk)
        content = request.POST.get('content')
        # post -> object를 가져오거나 페이지가 없다는 뜻을 가져옴
        # content -> POST로 받은 것의 'content'를 받아옴. 댓글의 내용.

    if not content:
        return HttpResponse('댓글 내용을 입력하세요', status=400)

    # 댓글이 생성 시 각 속성을 지정.
    Comment.objects.create(
        post = post,
        author= request.user,
        content = content,
    )
    # 지정이 끝나면 review_list로 결과물을 보내줌.
    return redirect('post:review_list')