from django import forms
from .models import FileModel, Comment, Review

# FileModel에 대한 modelform
class FileForm(forms.ModelForm):
    class Meta:
        model = FileModel
        fields = ('title', 'file')

    def __init__(self, *args, **kwargs):
        super(FileForm, self).__init__(*args, **kwargs)
        self.fields['file'].required = False


# Comment에 대한 모델 폼.
class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = (
            'content',
        )
        widgets = {
            'content': forms.TextInput(
                attrs= {'class': 'content', 'placeholder': '댓글달기',}
            )
        }

    def clean_content(self):
        data = self.cleaned_data['content']
        errors = []
        if data == '':
            errors.append(forms.ValidationError('댓글 내용을 입력해주세요'))
        elif len(data) > 140:
            errors.append(forms.ValidationError('댓글 내용은 140자 이내로 입력해주세요.'))
        if errors:
            raise forms.ValidationError(errors)
        return data


# 리뷰를 위한 폼
# 각 클래스에서 Meta클래스에 필요한 모델을 가져오고 필요한 필드를 정의
class ReviewForm(forms.ModelForm):
    class Meta:
        model = Review
        fields = ('photo', 'content',)
        widgets = {'content': forms.TextInput(
            attrs= {'class': 'content', 'placeholder': '내용을 입력하세요.',}
        )}