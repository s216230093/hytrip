from django.urls import path
from . import views

app_name = 'post'

urlpatterns = [
    path('review/', views.review_list, name = 'review'),
    path('<int:review_id>/comment/create/', views.comment_create, name='comment_create')
]