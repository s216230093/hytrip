from django.contrib import admin
from .models import Post, PostAdmin, Review, Comment

admin.site.register(Post, PostAdmin)

admin.site.register(Review)
admin.site.register(Comment)
